rm /tmp/.testlock.*
