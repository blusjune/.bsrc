#!/bin/sh

#./.run_test.sh "fs250mb"
#./.run_test.sh "fs500mb"
./.run_test.sh "fs1gb"
#./.run_test.sh "fs2gb"
#./.run_test.sh "fs4gb"
#./.run_test.sh "fs8gb"

## _wl_name="wl.randomrw_r2w2_${_tname}";
## _tname ::= "fs250mb" | "fs500mb" | "fs1gb" | "fs2gb" | "fs4gb" | "fs8gb"

